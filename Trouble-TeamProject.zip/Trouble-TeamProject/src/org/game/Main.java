package org.game;

public class Main {
	
	@SuppressWarnings("unused")
	private static Game game;

	public static void main(String[] args) {

		game = new Game();

	}

}
